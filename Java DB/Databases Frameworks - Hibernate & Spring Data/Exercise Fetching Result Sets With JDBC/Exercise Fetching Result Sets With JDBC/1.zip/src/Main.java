import java.io.IOException;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        String URL = "jdbc:mysql://localhost:3306/MinionsDB";
        String USER = "root";
        String PASSWORD = "";

//        PreparedStatement prstmt;
//        ResultSet rs = null;

//        String selectPreparedSQL = "SELECT u.first_name, u.last_name, COUNT(ug.game_id)\n" +
//                "FROM users AS u\n" +
//                "JOIN users_games AS ug\n" +
//                "ON u.id = ug.user_id\n" +
//                "WHERE u.user_name = ?";
//
//        String userPlayer = "nakov";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            //prstmt = conn.prepareStatement(selectPreparedSQL);
            //prstmt.setString(1, userPlayer);

            //rs = prstmt.executeQuery();

//            if (rs != null) {
//                rs.beforeFirst();
//                while (rs.next()) {
//                    System.out.format("User: %s.%n", userPlayer);
//                    System.out.format("%s %s has played %d games.%n", rs.getString("first_name"), rs.getString("last_name"), rs.getInt(3));
//                }
//            } else {
//                System.out.println("No such user exists");
//            }
        } catch (SQLException e) {
            e.printStackTrace();
//        } finally {
//            if (rs != null) {
//                rs.close();
//            }
        }
    }
}
