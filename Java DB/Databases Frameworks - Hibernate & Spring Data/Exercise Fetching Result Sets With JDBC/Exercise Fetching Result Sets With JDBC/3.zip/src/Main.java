import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        PreparedStatement prstmt;
        ResultSet rs = null;

        String selectPreparedSQL = "SELECT v.name, m.id, m.name, m.age\n" +
                "FROM villains_minions AS vm\n" +
                "JOIN minions AS m\n" +
                "ON vm.minion_id = m.id\n" +
                "JOIN villains AS v\n" +
                "ON vm.villain_id = v.id\n" +
                "WHERE vm.villain_id = ?";

        String villainId = scanner.readLine();

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(selectPreparedSQL);
            prstmt.setInt(1, Integer.parseInt(villainId));

            rs = prstmt.executeQuery();
            int cnt = 0;
            if (rs != null) {
                rs.beforeFirst();
                if (!rs.next()) {
                    System.out.println("No villain with ID " + villainId + " exists in the database.");
                }
                rs.beforeFirst();
                while (rs.next()) {
                    if (cnt == 0) {
                        System.out.format("Villain: %s%n", rs.getString(1));
                    }
                    System.out.format("%d. %s %d%n", rs.getInt(2), rs.getString(3), rs.getInt(4));
                    cnt++;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
