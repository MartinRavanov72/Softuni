import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        List<Integer> minionIDs = Arrays.stream(scanner.readLine().split("\\s+")).map(Integer::parseInt).collect(Collectors.toList());

        PreparedStatement prstmt;
        ResultSet rs = null;

        String selectPreparedSQL = "UPDATE minions\n" +
                "SET minions.name = CONCAT(UPPER(LEFT(minions.name, 1)), RIGHT(minions.name, CHAR_LENGTH(minions.name) - 1)),\n" +
                "minions.age = minions.age + 1\n" +
                "WHERE minions.id = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(selectPreparedSQL);
            for (int i = 0; i < minionIDs.size(); i++) {
                prstmt.setInt(1, minionIDs.get(i));
                prstmt.executeUpdate();
            }
            prstmt = conn.prepareStatement("SELECT m.name, m.age\n" +
                    "FROM minions AS m");

            rs = prstmt.executeQuery();

            if (rs != null) {
                rs.beforeFirst();
                while (rs.next()) {
                    System.out.println(rs.getString(1) + " " + rs.getString(2));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
