import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        PreparedStatement prstmt;
        ResultSet rs = null;

        String selectPreparedSQL = "SELECT * FROM towns WHERE towns.name = ?";

        String minion = scanner.readLine();
        String villain = scanner.readLine();

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(selectPreparedSQL);
            prstmt.setString(1, minion.split("\\s+")[3]);

            rs = prstmt.executeQuery();
            if (rs != null) {
                rs.beforeFirst();
                if (!rs.next()) {
                    prstmt = conn.prepareStatement("INSERT INTO towns(name)\n" +
                            "VALUES(?)");
                    prstmt.setString(1, minion.split("\\s+")[3]);
                    prstmt.executeUpdate();
                    System.out.println("Town " + minion.split("\\s+")[3] + " was added to the database.");
                }
                prstmt = conn.prepareStatement("SELECT * FROM villains WHERE villains.name = ?");
                prstmt.setString(1, villain.split("\\s+")[1]);
                rs = prstmt.executeQuery();
                if (!rs.next()) {
                    prstmt = conn.prepareStatement("INSERT INTO villains(name, evilness_factor)\n" +
                            "VALUES(?, 'super evil')");
                    prstmt.setString(1, villain.split("\\s+")[1]);
                    prstmt.executeUpdate();
                    System.out.println("Villain " + villain.split("\\s+")[1] + " was added to the database.");
                }
                prstmt = conn.prepareStatement("INSERT INTO minions(name, age, town)\n" +
                        "VALUES(?, ?, ?)");
                prstmt.setString(1, minion.split("\\s+")[1]);
                prstmt.setInt(2, Integer.parseInt(minion.split("\\s+")[2]));
                prstmt.setString(3, minion.split("\\s+")[3]);
                prstmt.executeUpdate();
                prstmt = conn.prepareStatement("SELECT m.id\n" +
                        "FROM minions AS m\n" +
                        "WHERE m.name = ?");
                prstmt.setString(1, minion.split("\\s+")[1]);
                rs = prstmt.executeQuery();
                rs.beforeFirst();
                rs.next();
                int minionID = rs.getInt(1);
                prstmt = conn.prepareStatement("SELECT v.id\n" +
                        "FROM villains AS v\n" +
                        "WHERE v.name = ?");
                prstmt.setString(1, villain.split("\\s+")[1]);
                rs = prstmt.executeQuery();
                rs.beforeFirst();
                rs.next();
                int villainID = rs.getInt(1);
                prstmt = conn.prepareStatement("INSERT INTO villains_minions\n" +
                        "VALUES(?, ?)");
                prstmt.setInt(1, villainID);
                prstmt.setInt(2, minionID);
                prstmt.executeUpdate();
                System.out.println("Successfully added " + minion.split("\\s+")[1] + " to be minion of " + villain.split("\\s+")[1]);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
