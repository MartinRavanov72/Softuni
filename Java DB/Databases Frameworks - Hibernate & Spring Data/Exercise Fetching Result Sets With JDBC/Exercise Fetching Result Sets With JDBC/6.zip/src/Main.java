import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        PreparedStatement prstmt;
        ResultSet rs = null;

        String selectPreparedSQL = "SELECT v.id\n" +
                "FROM villains AS v\n" +
                "WHERE v.id = ?";

        String id = scanner.readLine();

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(selectPreparedSQL);
            prstmt.setInt(1, Integer.parseInt(id));

            rs = prstmt.executeQuery();

            if (rs != null) {
                rs.beforeFirst();
                if (!rs.next()) {
                    System.out.println("No such villain was found");
                } else {
                    prstmt = conn.prepareStatement("DELETE FROM villains_minions\n" +
                            "WHERE villains_minions.villain_id = ?");
                    prstmt.setInt(1, Integer.parseInt(id));
                    String output2 = prstmt.executeUpdate() + " minions released";
                    prstmt = conn.prepareStatement("SELECT v.name\n" +
                            "FROM villains AS v\n" +
                            "WHERE v.id = ?");
                    prstmt.setInt(1, Integer.parseInt(id));
                    rs = prstmt.executeQuery();
                    rs.beforeFirst();
                    rs.next();
                    String output1 = rs.getString(1) + " was deleted";
                    prstmt = conn.prepareStatement("DELETE FROM villains\n" +
                            "WHERE villains.id = ?");
                    prstmt.setInt(1, Integer.parseInt(id));
                    prstmt.executeUpdate();
                    System.out.println(output1);
                    System.out.println(output2);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
