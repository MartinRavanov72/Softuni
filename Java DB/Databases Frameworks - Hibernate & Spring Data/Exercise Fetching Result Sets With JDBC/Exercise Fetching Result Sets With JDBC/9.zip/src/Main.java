import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        PreparedStatement prstmt;
        ResultSet rs = null;

        int minionID = Integer.parseInt(scanner.readLine());

        String selectPreparedSQL = "CALL usp_get_older(?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(selectPreparedSQL);
            prstmt.setInt(1, minionID);

            prstmt.executeUpdate();

            prstmt = conn.prepareStatement("SELECT m.name, m.age\n" +
                    "FROM minions AS m\n" +
                    "WHERE m.id = ?");

            prstmt.setInt(1, minionID);

            rs = prstmt.executeQuery();
            if (rs != null) {
                rs.beforeFirst();
                while (rs.next()) {
                    System.out.println(rs.getString(1) + " " + rs.getString(2));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
