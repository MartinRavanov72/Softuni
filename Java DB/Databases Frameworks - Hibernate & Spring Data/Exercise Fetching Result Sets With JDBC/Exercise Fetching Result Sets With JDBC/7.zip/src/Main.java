import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        List<String> minionNames = new ArrayList<>();
        List<String> minionsArranged = new ArrayList<>();

        PreparedStatement prstmt;
        ResultSet rs = null;

        String selectPreparedSQL = "SELECT m.name\n" +
                "FROM minions AS m";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(selectPreparedSQL);

            rs = prstmt.executeQuery();

            if (rs != null) {
                rs.beforeFirst();
                while (rs.next()) {
                    minionNames.add(rs.getString(1));
                }
            }

            while(minionNames.size() > 0)
            {
                minionsArranged.add(minionNames.get(0));
                minionNames.remove(0);
                if(minionNames.size() > 0)
                {
                    minionsArranged.add(minionNames.get(minionNames.size() - 1));
                    minionNames.remove(minionNames.size() - 1);
                }
            }
            minionsArranged.stream().forEach(System.out::println);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
