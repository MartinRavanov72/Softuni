import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        PreparedStatement prstmt;
        ResultSet rs = null;

        String updatePreparedSQL = "UPDATE towns\n" +
                "SET towns.name = UPPER(towns.name)\n" +
                "WHERE towns.information LIKE(?)\n";

        String country = scanner.readLine();

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(updatePreparedSQL);
            prstmt.setString(1, country);

            int linesChanged = prstmt.executeUpdate();

            if (linesChanged == 0) {
                System.out.println("No town names were affected.");
            } else {
                System.out.println(linesChanged + " town names were affected.");
                prstmt = conn.prepareStatement("SELECT t.name\n" +
                        "FROM towns AS t\n" +
                        "WHERE t.information LIKE(?)");
                prstmt.setString(1, country);
                rs = prstmt.executeQuery();
                String output = "[";
                if (rs != null) {
                    rs.beforeFirst();
                    while (rs.next()) {
                        output += rs.getString(1);
                        output += ", ";
                    }
                }
                output = output.substring(0, output.length() - 2);
                output += "]";
                System.out.println(output);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
