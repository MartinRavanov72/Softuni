import java.io.IOException;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        String URL = "jdbc:mysql://localhost:3306/minionsdb";
        String USER = "root";
        String PASSWORD = "";

        PreparedStatement prstmt;
        ResultSet rs = null;

        String selectPreparedSQL = "SELECT v.name, COUNT(vm.minion_id) AS minions_count\n" +
                "FROM villains_minions AS vm\n" +
                "JOIN villains AS v\n" +
                "ON v.id = vm.villain_id\n" +
                "GROUP BY vm.villain_id\n" +
                "HAVING minions_count > 3\n" +
                "ORDER BY minions_count DESC;";

//        String userPlayer = "nakov";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            prstmt = conn.prepareStatement(selectPreparedSQL);
//            prstmt.setString(1, userPlayer);

            rs = prstmt.executeQuery();

            if (rs != null) {
                rs.beforeFirst();
                while (rs.next()) {
                    System.out.format("%s %s%n", rs.getString("name"), rs.getString("minions_count"));
                }
            } else {
//                System.out.println("No such user exists");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
        }
    }
}
