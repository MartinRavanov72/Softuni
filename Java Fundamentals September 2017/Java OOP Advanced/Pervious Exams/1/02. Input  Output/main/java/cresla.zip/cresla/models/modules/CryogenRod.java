package cresla.models.modules;

public class CryogenRod extends AbstractEnergyModule {
    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
