package cresla.interfaces;

public interface AbsorbingModule extends Module {
    int getHeatAbsorbing();
}
